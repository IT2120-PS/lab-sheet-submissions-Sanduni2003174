getwd()
setwd("C:\\Users\\egsag\\OneDrive\\Desktop\\IT24102856")
# Exercise 1
a <- 0
b <- 40

prob1 <- punif(25, min=a, max=b) - punif(10, min=a, max=b)
print(paste("Probability train arrives between 10 and 25 minutes:", prob1))

#Exercise 2

lambda <- 1/3  

prob2 <- pexp(2, rate=lambda)
print(paste("Probability update takes at most 2 hours:", prob2))


#Exercise 3(i)


mu <- 100
sigma <- 15

prob3_i <- 1 - pnorm(130, mean=mu, sd=sigma)
print(paste("Probability IQ > 130:", prob3_i))

# Exercise 3 (ii)
iq_95 <- qnorm(0.95, mean=mu, sd=sigma)
print(paste("95th percentile IQ score:", iq_95))


