setwd("C:\\Users\\IT24102856\\Desktop\\IT24102856")
getwd()
data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
fix(data)
attach(data)
data

data[[1]]

popmn <- mean(Weight.kg.)
popmn
popsd <- sd(Weight.kg.)
popsd

#First create null vectors to store sample data sets.
samples <-c()
n <-c()

for(i in 1:25){
  s<-sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(samples,s)
  n<<-c(n,paste('S',i))
}

colnames(samples)=n

s.means<-apply(samples,2,mean)
s.means
s.sds<-apply(samples,2,sd)
s.sds

mean.of.means<-mean(s.means)
mean.of.means
sd.of.means<-sd(s.means)
sd.of.means

cat("Population Mean:", popmn, "\n")
cat("Mean of Sample Means:", mean.of.means, "\n\n")

true.sd.error<-popsd/sqrt(6)
cat("Population Standard Deviation:", popsd, "\n")
cat("Standard Deviation of Sample Means:", sd.of.means, "\n")
cat("Theoretical Standard Error (pop_sd/sqrt(6)):", true.sd.error, "\n")