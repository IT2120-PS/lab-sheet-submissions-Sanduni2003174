setwd("C:\\Users\\IT24102856\\Desktop\\IT24102856")
getwd()

# 1. Set working directory (adjust the path if needed)
setwd("C:\\Users\\IT24102856\\Desktop\\IT24102856")
getwd()

# 2. Import dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# 3. Rename the column to something simple
names(Delivery_Times) <- "Times"
print(head(Delivery_Times))

# Extract the column for analysis
times <- Delivery_Times$Times

# 4. Histogram with 9 class intervals [20,70], right open
breaks <- seq(20, 70, length.out = 10)  # creates 9 intervals
hist(times,
     breaks = breaks,
     right = FALSE,     # right-open intervals
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     col = "lightblue",
     border = "black")

# 5. Cumulative frequency polygon (ogive)
hist_obj <- hist(times,
                 breaks = breaks,
                 right = FALSE,
                 plot = FALSE)   # just calculate frequencies

cum_freq <- cumsum(hist_obj$counts)

plot(hist_obj$breaks[-1], cum_freq,
     type = "o", pch = 16,
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     col = "blue")
